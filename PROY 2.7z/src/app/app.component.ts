import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ProfesoresComponent } from './profesores/profesores.component';
import { CarteleriaComponent } from './carteleria/carteleria.component';
import { LicenciasComponent } from './licencias/licencias.component';
import { IngresoComponent } from './ingreso/ingreso.component';
import { EncavezadoComponent } from "./encavezado/encavezado.component";
import { CargosComponent } from './cargos/cargos.component';

enum Permisos{
  USUARIO = "USUARIO",
  ADMINISTRADOR = "ADMINISTRADOR"
};

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [IngresoComponent, ProfesoresComponent, CarteleriaComponent, LicenciasComponent, RouterOutlet, EncavezadoComponent, CargosComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})

export class AppComponent {
  permiso = Permisos.USUARIO
  
  adminstrador() {
    if(this.permiso === "USUARIO"){
      this.permiso = Permisos.ADMINISTRADOR;
    } else {
      this.permiso = Permisos.USUARIO;
    }
  }
}