import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import axios from 'axios';

@Component({
  selector: 'app-cargos',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './cargos.component.html',
  styleUrl: './cargos.component.css'
})
export class CargosComponent {
  cargos$ = this.getCargos() 

  async getCargos(){
    return axios.get("http://localhost:6969/cargos").then(res => res.data);
  }
}
