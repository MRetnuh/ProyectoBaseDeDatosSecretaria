import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CarteleriaComponent } from './carteleria.component';

describe('CarteleriaComponent', () => {
  let component: CarteleriaComponent;
  let fixture: ComponentFixture<CarteleriaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CarteleriaComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CarteleriaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
