import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { toPng,toJpeg } from 'html-to-image';

@Component({
  selector: 'app-carteleria',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './carteleria.component.html',
  styleUrl: './carteleria.component.css'
})
export class CarteleriaComponent {
    titulo = new FormControl('TITULO');
    texto = new FormControl('TEXTO');
    fecha = new FormControl(new Date());
    async descargarImagen(){
      let nodo = document.getElementById("cartel") || document.createElement("p");
      console.log(nodo)
      window.open(await toPng(nodo)); 
      console.log(toJpeg(nodo));
}
}
