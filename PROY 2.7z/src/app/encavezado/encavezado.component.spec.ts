import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EncavezadoComponent } from './encavezado.component';

describe('EncavezadoComponent', () => {
  let component: EncavezadoComponent;
  let fixture: ComponentFixture<EncavezadoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EncavezadoComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EncavezadoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
