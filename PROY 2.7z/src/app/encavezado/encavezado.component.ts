import { Component } from '@angular/core';

@Component({
  selector: 'app-encavezado',
  standalone: true,
  imports: [],
  templateUrl: './encavezado.component.html',
  styleUrl: './encavezado.component.css'
})
export class EncavezadoComponent {
  imageSrc = "/35.png"

}
