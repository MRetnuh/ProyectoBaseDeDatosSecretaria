import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-ingreso',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './ingreso.component.html',
  styleUrl: './ingreso.component.css'
})
export class IngresoComponent {
    nombreInput = new FormControl('Nombre');
    apellidoInput = new FormControl('Apellido');
    fechaNacimientoInput = new FormControl(new Date());
    telefonoInput  = new FormControl('Numero');
    domiciloInput = new FormControl('domicilio');
    emailInput = new FormControl('email');

    datos = {
      nombre : this.nombreInput,
      apellido : this.apellidoInput,
      fechaNacimiento : this.fechaNacimientoInput,
      telefono : this.telefonoInput,
      domicilio : this.domiciloInput,
      email : this.emailInput
    }

    enviarObjeto() {
      console.log(this.datos)
    }
}
