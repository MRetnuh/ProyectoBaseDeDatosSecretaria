import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import axios from 'axios';

@Component({
  selector: 'app-licencias',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './licencias.component.html',
  styleUrl: './licencias.component.css'
})


export class LicenciasComponent {
  licencias$ = this.getLicencias()

  async getLicencias(){
    return axios.get("http://localhost:6969/licencias").then(res => res.data);
  }
}
