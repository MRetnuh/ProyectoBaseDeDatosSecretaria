import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { toPng,toJpeg } from 'html-to-image';
import axios from 'axios';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-profesores',
  standalone: true,
  imports: [ReactiveFormsModule,CommonModule ],
  templateUrl: './profesores.component.html',
  styleUrl: './profesores.component.css'
})


export class ProfesoresComponent {
  profesores$ = this.getProfesores(); // Cambiamos a un observable o promesa

  async getProfesores() {
    return axios.get("http://localhost:6969/profesores").then(res => res.data);
  }
}


